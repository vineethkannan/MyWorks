package com.diviso.admin.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A Generals.
 */
@Entity
@Table(name = "generals")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Generals implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "terminal_name")
    private String terminalName;

    @Lob
    @Column(name = "logo")
    private byte[] logo;

    @Column(name = "logo_content_type")
    private String logoContentType;

    @Lob
    @Column(name = "text")
    private byte[] text;

    @Column(name = "text_content_type")
    private String textContentType;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTerminalName() {
        return terminalName;
    }

    public Generals terminalName(String terminalName) {
        this.terminalName = terminalName;
        return this;
    }

    public void setTerminalName(String terminalName) {
        this.terminalName = terminalName;
    }

    public byte[] getLogo() {
        return logo;
    }

    public Generals logo(byte[] logo) {
        this.logo = logo;
        return this;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public String getLogoContentType() {
        return logoContentType;
    }

    public Generals logoContentType(String logoContentType) {
        this.logoContentType = logoContentType;
        return this;
    }

    public void setLogoContentType(String logoContentType) {
        this.logoContentType = logoContentType;
    }

    public byte[] getText() {
        return text;
    }

    public Generals text(byte[] text) {
        this.text = text;
        return this;
    }

    public void setText(byte[] text) {
        this.text = text;
    }

    public String getTextContentType() {
        return textContentType;
    }

    public Generals textContentType(String textContentType) {
        this.textContentType = textContentType;
        return this;
    }

    public void setTextContentType(String textContentType) {
        this.textContentType = textContentType;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Generals generals = (Generals) o;
        if (generals.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), generals.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Generals{" +
            "id=" + getId() +
            ", terminalName='" + getTerminalName() + "'" +
            ", logo='" + getLogo() + "'" +
            ", logoContentType='" + getLogoContentType() + "'" +
            ", text='" + getText() + "'" +
            ", textContentType='" + getTextContentType() + "'" +
            "}";
    }
}
