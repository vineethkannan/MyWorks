/**
 * JPA domain objects.
 */
package com.diviso.admin.domain;
