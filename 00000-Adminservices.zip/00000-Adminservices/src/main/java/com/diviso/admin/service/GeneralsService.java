package com.diviso.admin.service;

import com.diviso.admin.service.dto.GeneralsDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing Generals.
 */
public interface GeneralsService {

    /**
     * Save a generals.
     *
     * @param generalsDTO the entity to save
     * @return the persisted entity
     */
    GeneralsDTO save(GeneralsDTO generalsDTO);

    /**
     * Get all the generals.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<GeneralsDTO> findAll(Pageable pageable);

    /**
     * Get the "id" generals.
     *
     * @param id the id of the entity
     * @return the entity
     */
    GeneralsDTO findOne(Long id);

    /**
     * Delete the "id" generals.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
