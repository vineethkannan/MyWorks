package com.diviso.admin.service.impl;

import com.diviso.admin.service.GeneralsService;
import com.diviso.admin.domain.Generals;
import com.diviso.admin.repository.GeneralsRepository;
import com.diviso.admin.service.dto.GeneralsDTO;
import com.diviso.admin.service.mapper.GeneralsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing Generals.
 */
@Service
@Transactional
public class GeneralsServiceImpl implements GeneralsService {

    private final Logger log = LoggerFactory.getLogger(GeneralsServiceImpl.class);

    private final GeneralsRepository generalsRepository;

    private final GeneralsMapper generalsMapper;

    public GeneralsServiceImpl(GeneralsRepository generalsRepository, GeneralsMapper generalsMapper) {
        this.generalsRepository = generalsRepository;
        this.generalsMapper = generalsMapper;
    }

    /**
     * Save a generals.
     *
     * @param generalsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public GeneralsDTO save(GeneralsDTO generalsDTO) {
        log.debug("Request to save Generals : {}", generalsDTO);
        Generals generals = generalsMapper.toEntity(generalsDTO);
        generals = generalsRepository.save(generals);
        return generalsMapper.toDto(generals);
    }

    /**
     * Get all the generals.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<GeneralsDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Generals");
        return generalsRepository.findAll(pageable)
            .map(generalsMapper::toDto);
    }

    /**
     * Get one generals by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public GeneralsDTO findOne(Long id) {
        log.debug("Request to get Generals : {}", id);
        Generals generals = generalsRepository.findOne(id);
        return generalsMapper.toDto(generals);
    }

    /**
     * Delete the generals by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Generals : {}", id);
        generalsRepository.delete(id);
    }
}
