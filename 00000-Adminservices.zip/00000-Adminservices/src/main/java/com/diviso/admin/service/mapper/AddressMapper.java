package com.diviso.admin.service.mapper;

import com.diviso.admin.domain.*;
import com.diviso.admin.service.dto.AddressDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Address and its DTO AddressDTO.
 */
@Mapper(componentModel = "spring", uses = {ShopMapper.class})
public interface AddressMapper extends EntityMapper<AddressDTO, Address> {

    @Mapping(source = "shop.id", target = "shopId")
    AddressDTO toDto(Address address);

    @Mapping(source = "shopId", target = "shop")
    @Mapping(target = "countries", ignore = true)
    Address toEntity(AddressDTO addressDTO);

    default Address fromId(Long id) {
        if (id == null) {
            return null;
        }
        Address address = new Address();
        address.setId(id);
        return address;
    }
}
