package com.diviso.admin.service.mapper;

import com.diviso.admin.domain.*;
import com.diviso.admin.service.dto.CountryDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Country and its DTO CountryDTO.
 */
@Mapper(componentModel = "spring", uses = {AddressMapper.class})
public interface CountryMapper extends EntityMapper<CountryDTO, Country> {

    @Mapping(source = "address.id", target = "addressId")
    CountryDTO toDto(Country country);

    @Mapping(target = "states", ignore = true)
    @Mapping(source = "addressId", target = "address")
    Country toEntity(CountryDTO countryDTO);

    default Country fromId(Long id) {
        if (id == null) {
            return null;
        }
        Country country = new Country();
        country.setId(id);
        return country;
    }
}
