package com.diviso.admin.service.mapper;

import com.diviso.admin.domain.*;
import com.diviso.admin.service.dto.GeneralsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Generals and its DTO GeneralsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface GeneralsMapper extends EntityMapper<GeneralsDTO, Generals> {



    default Generals fromId(Long id) {
        if (id == null) {
            return null;
        }
        Generals generals = new Generals();
        generals.setId(id);
        return generals;
    }
}
