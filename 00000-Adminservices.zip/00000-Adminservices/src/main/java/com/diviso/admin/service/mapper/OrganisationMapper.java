package com.diviso.admin.service.mapper;

import com.diviso.admin.domain.*;
import com.diviso.admin.service.dto.OrganisationDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Organisation and its DTO OrganisationDTO.
 */
@Mapper(componentModel = "spring", uses = {AddressMapper.class, ContactMapper.class})
public interface OrganisationMapper extends EntityMapper<OrganisationDTO, Organisation> {

    @Mapping(source = "address.id", target = "addressId")
    @Mapping(source = "contact.id", target = "contactId")
    OrganisationDTO toDto(Organisation organisation);

    @Mapping(source = "addressId", target = "address")
    @Mapping(source = "contactId", target = "contact")
    @Mapping(target = "shops", ignore = true)
    Organisation toEntity(OrganisationDTO organisationDTO);

    default Organisation fromId(Long id) {
        if (id == null) {
            return null;
        }
        Organisation organisation = new Organisation();
        organisation.setId(id);
        return organisation;
    }
}
