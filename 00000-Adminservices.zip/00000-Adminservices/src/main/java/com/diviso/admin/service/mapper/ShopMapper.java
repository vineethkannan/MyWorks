package com.diviso.admin.service.mapper;

import com.diviso.admin.domain.*;
import com.diviso.admin.service.dto.ShopDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Shop and its DTO ShopDTO.
 */
@Mapper(componentModel = "spring", uses = {OrganisationMapper.class, ContactMapper.class})
public interface ShopMapper extends EntityMapper<ShopDTO, Shop> {

    @Mapping(source = "organisation.id", target = "organisationId")
    @Mapping(source = "contact.id", target = "contactId")
    ShopDTO toDto(Shop shop);

    @Mapping(source = "organisationId", target = "organisation")
    @Mapping(source = "contactId", target = "contact")
    @Mapping(target = "addresses", ignore = true)
    Shop toEntity(ShopDTO shopDTO);

    default Shop fromId(Long id) {
        if (id == null) {
            return null;
        }
        Shop shop = new Shop();
        shop.setId(id);
        return shop;
    }
}
