/**
 * Service layer beans.
 */
package com.diviso.admin.service;
