/**
 * Spring MVC REST controllers.
 */
package com.diviso.admin.web.rest;
