/**
 * View Models used by Spring MVC REST controllers.
 */
package com.diviso.admin.web.rest.vm;
