package com.diviso.admin.web.rest;

import com.diviso.admin.AdminservicesApp;

import com.diviso.admin.domain.Generals;
import com.diviso.admin.repository.GeneralsRepository;
import com.diviso.admin.service.GeneralsService;
import com.diviso.admin.service.dto.GeneralsDTO;
import com.diviso.admin.service.mapper.GeneralsMapper;
import com.diviso.admin.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;

import javax.persistence.EntityManager;
import java.util.List;

import static com.diviso.admin.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the GeneralsResource REST controller.
 *
 * @see GeneralsResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = AdminservicesApp.class)
public class GeneralsResourceIntTest {

    private static final String DEFAULT_TERMINAL_NAME = "AAAAAAAAAA";
    private static final String UPDATED_TERMINAL_NAME = "BBBBBBBBBB";

    private static final byte[] DEFAULT_LOGO = TestUtil.createByteArray(1, "0");
    private static final byte[] UPDATED_LOGO = TestUtil.createByteArray(2, "1");
    private static final String DEFAULT_LOGO_CONTENT_TYPE = "image/jpg";
    private static final String UPDATED_LOGO_CONTENT_TYPE = "image/png";

    private static final byte[] DEFAULT_TEXT = TestUtil.createByteArray(1, "0");
    private static final byte[] UPDATED_TEXT = TestUtil.createByteArray(2, "1");
    private static final String DEFAULT_TEXT_CONTENT_TYPE = "image/jpg";
    private static final String UPDATED_TEXT_CONTENT_TYPE = "image/png";

    @Autowired
    private GeneralsRepository generalsRepository;

    @Autowired
    private GeneralsMapper generalsMapper;

    @Autowired
    private GeneralsService generalsService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restGeneralsMockMvc;

    private Generals generals;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final GeneralsResource generalsResource = new GeneralsResource(generalsService);
        this.restGeneralsMockMvc = MockMvcBuilders.standaloneSetup(generalsResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Generals createEntity(EntityManager em) {
        Generals generals = new Generals()
            .terminalName(DEFAULT_TERMINAL_NAME)
            .logo(DEFAULT_LOGO)
            .logoContentType(DEFAULT_LOGO_CONTENT_TYPE)
            .text(DEFAULT_TEXT)
            .textContentType(DEFAULT_TEXT_CONTENT_TYPE);
        return generals;
    }

    @Before
    public void initTest() {
        generals = createEntity(em);
    }

    @Test
    @Transactional
    public void createGenerals() throws Exception {
        int databaseSizeBeforeCreate = generalsRepository.findAll().size();

        // Create the Generals
        GeneralsDTO generalsDTO = generalsMapper.toDto(generals);
        restGeneralsMockMvc.perform(post("/api/generals")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(generalsDTO)))
            .andExpect(status().isCreated());

        // Validate the Generals in the database
        List<Generals> generalsList = generalsRepository.findAll();
        assertThat(generalsList).hasSize(databaseSizeBeforeCreate + 1);
        Generals testGenerals = generalsList.get(generalsList.size() - 1);
        assertThat(testGenerals.getTerminalName()).isEqualTo(DEFAULT_TERMINAL_NAME);
        assertThat(testGenerals.getLogo()).isEqualTo(DEFAULT_LOGO);
        assertThat(testGenerals.getLogoContentType()).isEqualTo(DEFAULT_LOGO_CONTENT_TYPE);
        assertThat(testGenerals.getText()).isEqualTo(DEFAULT_TEXT);
        assertThat(testGenerals.getTextContentType()).isEqualTo(DEFAULT_TEXT_CONTENT_TYPE);
    }

    @Test
    @Transactional
    public void createGeneralsWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = generalsRepository.findAll().size();

        // Create the Generals with an existing ID
        generals.setId(1L);
        GeneralsDTO generalsDTO = generalsMapper.toDto(generals);

        // An entity with an existing ID cannot be created, so this API call must fail
        restGeneralsMockMvc.perform(post("/api/generals")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(generalsDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Generals in the database
        List<Generals> generalsList = generalsRepository.findAll();
        assertThat(generalsList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllGenerals() throws Exception {
        // Initialize the database
        generalsRepository.saveAndFlush(generals);

        // Get all the generalsList
        restGeneralsMockMvc.perform(get("/api/generals?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(generals.getId().intValue())))
            .andExpect(jsonPath("$.[*].terminalName").value(hasItem(DEFAULT_TERMINAL_NAME.toString())))
            .andExpect(jsonPath("$.[*].logoContentType").value(hasItem(DEFAULT_LOGO_CONTENT_TYPE)))
            .andExpect(jsonPath("$.[*].logo").value(hasItem(Base64Utils.encodeToString(DEFAULT_LOGO))))
            .andExpect(jsonPath("$.[*].textContentType").value(hasItem(DEFAULT_TEXT_CONTENT_TYPE)))
            .andExpect(jsonPath("$.[*].text").value(hasItem(Base64Utils.encodeToString(DEFAULT_TEXT))));
    }

    @Test
    @Transactional
    public void getGenerals() throws Exception {
        // Initialize the database
        generalsRepository.saveAndFlush(generals);

        // Get the generals
        restGeneralsMockMvc.perform(get("/api/generals/{id}", generals.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(generals.getId().intValue()))
            .andExpect(jsonPath("$.terminalName").value(DEFAULT_TERMINAL_NAME.toString()))
            .andExpect(jsonPath("$.logoContentType").value(DEFAULT_LOGO_CONTENT_TYPE))
            .andExpect(jsonPath("$.logo").value(Base64Utils.encodeToString(DEFAULT_LOGO)))
            .andExpect(jsonPath("$.textContentType").value(DEFAULT_TEXT_CONTENT_TYPE))
            .andExpect(jsonPath("$.text").value(Base64Utils.encodeToString(DEFAULT_TEXT)));
    }

    @Test
    @Transactional
    public void getNonExistingGenerals() throws Exception {
        // Get the generals
        restGeneralsMockMvc.perform(get("/api/generals/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateGenerals() throws Exception {
        // Initialize the database
        generalsRepository.saveAndFlush(generals);
        int databaseSizeBeforeUpdate = generalsRepository.findAll().size();

        // Update the generals
        Generals updatedGenerals = generalsRepository.findOne(generals.getId());
        // Disconnect from session so that the updates on updatedGenerals are not directly saved in db
        em.detach(updatedGenerals);
        updatedGenerals
            .terminalName(UPDATED_TERMINAL_NAME)
            .logo(UPDATED_LOGO)
            .logoContentType(UPDATED_LOGO_CONTENT_TYPE)
            .text(UPDATED_TEXT)
            .textContentType(UPDATED_TEXT_CONTENT_TYPE);
        GeneralsDTO generalsDTO = generalsMapper.toDto(updatedGenerals);

        restGeneralsMockMvc.perform(put("/api/generals")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(generalsDTO)))
            .andExpect(status().isOk());

        // Validate the Generals in the database
        List<Generals> generalsList = generalsRepository.findAll();
        assertThat(generalsList).hasSize(databaseSizeBeforeUpdate);
        Generals testGenerals = generalsList.get(generalsList.size() - 1);
        assertThat(testGenerals.getTerminalName()).isEqualTo(UPDATED_TERMINAL_NAME);
        assertThat(testGenerals.getLogo()).isEqualTo(UPDATED_LOGO);
        assertThat(testGenerals.getLogoContentType()).isEqualTo(UPDATED_LOGO_CONTENT_TYPE);
        assertThat(testGenerals.getText()).isEqualTo(UPDATED_TEXT);
        assertThat(testGenerals.getTextContentType()).isEqualTo(UPDATED_TEXT_CONTENT_TYPE);
    }

    @Test
    @Transactional
    public void updateNonExistingGenerals() throws Exception {
        int databaseSizeBeforeUpdate = generalsRepository.findAll().size();

        // Create the Generals
        GeneralsDTO generalsDTO = generalsMapper.toDto(generals);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restGeneralsMockMvc.perform(put("/api/generals")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(generalsDTO)))
            .andExpect(status().isCreated());

        // Validate the Generals in the database
        List<Generals> generalsList = generalsRepository.findAll();
        assertThat(generalsList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteGenerals() throws Exception {
        // Initialize the database
        generalsRepository.saveAndFlush(generals);
        int databaseSizeBeforeDelete = generalsRepository.findAll().size();

        // Get the generals
        restGeneralsMockMvc.perform(delete("/api/generals/{id}", generals.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Generals> generalsList = generalsRepository.findAll();
        assertThat(generalsList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Generals.class);
        Generals generals1 = new Generals();
        generals1.setId(1L);
        Generals generals2 = new Generals();
        generals2.setId(generals1.getId());
        assertThat(generals1).isEqualTo(generals2);
        generals2.setId(2L);
        assertThat(generals1).isNotEqualTo(generals2);
        generals1.setId(null);
        assertThat(generals1).isNotEqualTo(generals2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(GeneralsDTO.class);
        GeneralsDTO generalsDTO1 = new GeneralsDTO();
        generalsDTO1.setId(1L);
        GeneralsDTO generalsDTO2 = new GeneralsDTO();
        assertThat(generalsDTO1).isNotEqualTo(generalsDTO2);
        generalsDTO2.setId(generalsDTO1.getId());
        assertThat(generalsDTO1).isEqualTo(generalsDTO2);
        generalsDTO2.setId(2L);
        assertThat(generalsDTO1).isNotEqualTo(generalsDTO2);
        generalsDTO1.setId(null);
        assertThat(generalsDTO1).isNotEqualTo(generalsDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(generalsMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(generalsMapper.fromId(null)).isNull();
    }
}
